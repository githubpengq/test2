package gui.ava.html.exception;

/**
 * @author Yoav Aharoni
 */
public class RenderException extends RuntimeException {
	public RenderException(String message, Throwable cause) {
		super(message, cause);
	}
}
