package gui.ava.html.parser;

import org.w3c.dom.Document;

/**
 * @author Yoav Aharoni
 */
public interface DocumentHolder {
	Document getDocument();
}
