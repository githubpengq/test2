package gui.ava.html.parser;

/**
 * @author Yoav Aharoni
 */
public class ParseException extends RuntimeException {
	public ParseException(String message, Throwable cause) {
		super(message, cause);
	}
}
