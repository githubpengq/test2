package gui.ava.html.renderer;

import org.xhtmlrenderer.render.Box;

/**
 * @author Yoav Aharoni
 */
public interface LayoutHolder {
	Box getRootBox();
}
